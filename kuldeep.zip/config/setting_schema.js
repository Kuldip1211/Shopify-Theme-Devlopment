[
    {
        "name" : "theme_info",
        "theme_name" : "theme_from_scratch",
        "theme_version" : "1.0.0",
        "theme_author" : "Kuldeep Chudasama",
        "theme_description" : "A custom theme built from scratch."
    }
]